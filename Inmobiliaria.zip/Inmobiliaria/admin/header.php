<header>
    <h1>Administración de Inmobiliaria</h1>
    <h2>Sistema de Administración Web Para Inmobiliaria</h2>
</header>  